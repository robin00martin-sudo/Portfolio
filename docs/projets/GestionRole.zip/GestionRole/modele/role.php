<?php
require_once 'bd.inc.php';

function getRoles() {
    $bd = connexionPDO();
    return $bd->query("SELECT * FROM role")->fetchAll();
}

function affecterRole($idUser, $idRole) {
    $bd = connexionPDO();
    $req = $bd->prepare("
        INSERT INTO utilisateur_role (idUtilisateur, idRole)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE idRole = VALUES(idRole)
    ");
    $req->execute([$idUser, $idRole]);
}
