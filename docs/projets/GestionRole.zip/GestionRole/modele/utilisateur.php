<?php
require_once RACINE . '/modele/bd.inc.php';

/**
 * Retourne la liste de tous les utilisateurs.
 */
function getUtilisateurs() {
    try {
        $bd = connexionPDO();
        return $bd->query("SELECT * FROM utilisateur")->fetchAll();
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Vérifie si un login est déjà utilisé en base.
 */
function loginExiste($login) {
    try {
        $bd  = connexionPDO();
        $req = $bd->prepare("SELECT COUNT(*) FROM utilisateur WHERE login = ?");
        $req->execute([$login]);
        return $req->fetchColumn() > 0;
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Valide la force du mot de passe.
 * Retourne un message d'erreur si invalide, chaîne vide si valide.
 */
function validerMotDePasse($mdp) {
    if (strlen($mdp) < 8) {
        return "Le mot de passe doit contenir au moins 8 caractères.";
    }
    if (!preg_match('/[A-Z]/', $mdp)) {
        return "Le mot de passe doit contenir au moins une lettre majuscule.";
    }
    if (!preg_match('/[a-z]/', $mdp)) {
        return "Le mot de passe doit contenir au moins une lettre minuscule.";
    }
    if (!preg_match('/[0-9]/', $mdp)) {
        return "Le mot de passe doit contenir au moins un chiffre.";
    }
    if (!preg_match('/[\W_]/', $mdp)) {
        return "Le mot de passe doit contenir au moins un caractère spécial (ex : @, #, !, ...).";
    }
    return "";
}

/**
 * Crée un nouvel utilisateur avec le mot de passe hashé.
 */
function ajouterUtilisateur($login, $mdp) {
    try {
        $bd      = connexionPDO();
        $mdpHash = password_hash($mdp, PASSWORD_DEFAULT);
        $req     = $bd->prepare("INSERT INTO utilisateur(login, mdp) VALUES (?, ?)");
        $req->execute([$login, $mdpHash]);
        return true;
    } catch (Exception $e) {
        return false;
    }
}
?>