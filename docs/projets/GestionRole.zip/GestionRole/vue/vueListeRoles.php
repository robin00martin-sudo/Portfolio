<?php require 'entete.php'; ?>
<div class="container">
<h2>Roles</h2>
<ul>
<?php foreach ($roles as $r) { ?>
    <li><?= $r['nom'] ?></li>
<?php } ?>
</ul>
</div>
<?php require 'pied.php'; ?>