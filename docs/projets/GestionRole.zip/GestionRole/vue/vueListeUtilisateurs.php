<?php require 'entete.php'; ?>
<div class= "container">
<h2>Utilisateurs</h2>
<ul>
<?php foreach ($utilisateurs as $u) { ?>
    <li><?= $u['login'] ?></li>
<?php } ?>
</ul>
</div>
<?php require 'pied.php'; ?>