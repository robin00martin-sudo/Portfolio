<div class="container">

    <h1>Inscription</h1>

    <?php if (!empty($erreur)) : ?>
        <p class="error"><?= htmlspecialchars($erreur) ?></p>
    <?php endif; ?>

    <form method="POST" action="index.php?action=inscription">

        <label for="login">Login</label>
        <input type="text" id="login" name="login"
               placeholder="Choisissez un login"
               value="<?= htmlspecialchars($_POST['login'] ?? '') ?>"
               required>
        <?php if (!empty($erreurLogin)) : ?>
            <p class="error"><?= htmlspecialchars($erreurLogin) ?></p>
        <?php endif; ?>

        <label for="mdp">Mot de passe</label>
        <input type="password" id="mdp" name="mdp"
               placeholder="Choisissez un mot de passe" required>

        <label for="mdp_confirm">Confirmer le mot de passe</label>
        <input type="password" id="mdp_confirm" name="mdp_confirm"
               placeholder="Répétez votre mot de passe" required>

        <?php if (!empty($erreurMdp)) : ?>
            <p class="error"><?= htmlspecialchars($erreurMdp) ?></p>
        <?php endif; ?>

        <p class="mdp-hint">
            Le mot de passe doit contenir au moins 8 caractères, une majuscule,
            une minuscule, un chiffre et un caractère spécial.
        </p>

        <button type="submit">Créer mon compte</button>
    </form>

    <p class="link-secondary">
        Déjà un compte ? <a href="index.php?action=connexion">Se connecter</a>
    </p>

</div>
