<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Utilisateurs & Rôles</title>
    <link rel="stylesheet" href="vue/CSS/style.css">
</head>
<body>

<nav>
    <?php if (isset($_SESSION['user'])) : ?>
        <!-- Liens visibles uniquement quand on est connecté -->
        <a href="index.php?action=listeUtilisateurs">Utilisateurs</a>
        <a href="index.php?action=roles">Rôles</a>
        <a href="index.php?action=affectation">Affectation</a>
        <a href="index.php?action=deconnexion">Déconnexion</a>
    <?php else : ?>
        <!-- Liens visibles quand on n'est pas connecté -->
        <a href="index.php?action=connexion">Connexion</a>
        <a href="index.php?action=inscription">Inscription</a>
    <?php endif; ?>
</nav>
