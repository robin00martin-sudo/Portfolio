<?php
require_once RACINE . '/modele/utilisateur.php';

// Récupérer les utilisateurs et afficher la vue
$utilisateurs = getUtilisateurs();
require RACINE . '/vue/vueListeUtilisateurs.php';
?>