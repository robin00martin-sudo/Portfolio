<?php
require_once RACINE . '/modele/role.php';
$roles = getRoles();
require RACINE . '/vue/vueListeRoles.php';
?>
