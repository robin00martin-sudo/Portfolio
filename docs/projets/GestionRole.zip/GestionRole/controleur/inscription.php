<?php
// session_start() est déjà appelé dans index.php

require_once RACINE . '/modele/utilisateur.php';

$erreur      = "";
$erreurLogin = "";
$erreurMdp   = "";

// Traitement du formulaire d'inscription
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $login = trim($_POST['login'] ?? '');
    $mdp   = $_POST['mdp']         ?? '';
    $mdp2  = $_POST['mdp_confirm'] ?? '';

    // 1. Champs vides
    if (empty($login) || empty($mdp) || empty($mdp2)) {
        $erreur = "Veuillez remplir tous les champs.";

    // 2. Login déjà utilisé
    } elseif (loginExiste($login)) {
        $erreurLogin = "Ce login est déjà utilisé. Veuillez en choisir un autre.";

    // 3. Validation du mot de passe
    } else {
        $erreurMdp = validerMotDePasse($mdp);

        if (!empty($erreurMdp)) {
            // Message d'erreur renvoyé par validerMotDePasse()

        // 4. Confirmation du mot de passe
        } elseif ($mdp !== $mdp2) {
            $erreurMdp = "Les deux mots de passe ne correspondent pas.";

        } else {
            // Tout est valide → création du compte
            $ok = ajouterUtilisateur($login, $mdp);

            if ($ok) {
                $_SESSION['message_succes'] = "Votre compte a bien été créé. Vous pouvez maintenant vous connecter.";
                header('Location: index.php?action=connexion');
                exit();
            } else {
                $erreur = "Une erreur est survenue lors de la création du compte. Veuillez réessayer.";
            }
        }
    }
}
require RACINE . '/vue/entete.php';
require RACINE . '/vue/vueInscription.php';
require RACINE . '/vue/pied.php';
?>
