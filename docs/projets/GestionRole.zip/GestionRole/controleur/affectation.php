<?php
// session_start() est déjà appelé dans index.php

require_once RACINE . '/modele/utilisateur.php';
require_once RACINE . '/modele/role.php';

// Vérification : l'utilisateur doit être connecté pour accéder à cette page
if (!isset($_SESSION['user'])) {
    // On lui explique pourquoi il est redirigé
    $_SESSION['message_succes'] = "";
    $_SESSION['message_erreur'] = "Vous devez être connecté pour accéder à la gestion des affectations.";
    header('Location: index.php?action=connexion');
    exit();
}

$message        = "";
$message_classe = "";

// Traitement du formulaire d'affectation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idUser = $_POST['user'] ?? null;
    $idRole = $_POST['role'] ?? null;

    if ($idUser && $idRole) {
        affecterRole($idUser, $idRole);
        $message        = "Le rôle a bien été affecté.";
        $message_classe = "success";
    } else {
        $message        = "Erreur : veuillez sélectionner un utilisateur et un rôle.";
        $message_classe = "error";
    }
}

// Récupération des données pour la vue
$users = getUtilisateurs();
$roles = getRoles();

// Affichage
require RACINE . '/vue/entete.php';
require RACINE . '/vue/vueAffectation.php';
require RACINE . '/vue/pied.php';
?>
