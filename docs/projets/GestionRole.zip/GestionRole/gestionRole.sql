CREATE DATABASE gestion_role;
USE gestion_role;

CREATE TABLE utilisateur (
    id    INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(50)  NOT NULL UNIQUE,
    mdp   VARCHAR(255) NOT NULL
);

CREATE TABLE role (
    id  INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE utilisateur_role (
    idUtilisateur INT PRIMARY KEY,
    idRole        INT,
    FOREIGN KEY (idUtilisateur) REFERENCES utilisateur(id),
    FOREIGN KEY (idRole)        REFERENCES role(id)
);

INSERT INTO role(nom) VALUES ('admin'), ('user');
